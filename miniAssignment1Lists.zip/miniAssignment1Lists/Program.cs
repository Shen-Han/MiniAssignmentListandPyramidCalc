﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace miniAssignment1Lists
{
    class Program
    {
        static void Main(string[] args)
        {
            //Have to set the userNumEntry variable right now for the bool on 34 to work.
            //Chose decimal as the variable type for ease. 
            String userNumberEntry;
            List<decimal> list = new List<decimal>();
            decimal userNumEntry = 0;
            String userEntry;

            //Old code

            //Console.WriteLine("Please enter Y if you want to enter a number.");                
            //if (userEntry.Equals("y"))
            //{
            //int userNumberEntry = 0;

            //Make the ask go up to any number I want. 
            for (int i = 1; i <= 5000; i++)
            {
                //Prompt the user every time to enter y or not before entering a number per the assignment instructions.
                Console.WriteLine("Would you like to enter a number (y) or not (any other key)");
                userEntry = Console.ReadLine();

                //Both capital and small case y will work.
                if (userEntry.Equals("y")||userEntry.Equals("Y"))
                {
                    //Console takes a String input first.
                    Console.WriteLine("Please enter a number");
                    userNumberEntry = Console.ReadLine();                  

                    //Test if the String input can be converted into a number, decimal in this case.
                    //If yes, userNumEntry will convert the String into a decimal for use later.
                    //Otherwise, the console will prompt the user to enter an actual number.
                    bool numberValidation = decimal.TryParse(userNumberEntry, out userNumEntry);   

                    if (numberValidation)
                    {
                        userNumEntry = Convert.ToDecimal(userNumberEntry);
                        list.Add(userNumEntry);
                    }

                    else
                    {
                        Console.WriteLine("Please enter an actual number");
                    }
                }
                else
                {
                    //Deleted old html/java style max and min code and used a much more compact premade method to find max min and avg.

                    Console.WriteLine("The largest number in the list is "+list.Max());
                    Console.WriteLine("The smallest number in the list is "+list.Min());
                    Console.WriteLine("The average of all numbers entered is "+list.Average());
                    Console.WriteLine("The list of numbers entered is:");
                    foreach (decimal a in list)
                        Console.WriteLine(a);     
                    
                    //Stop the code once this point is reached, otherwise the program will write the above lines and continue to ask for input.
                    break;


                    //Old Code

                    /*decimal max = 0;
                    decimal min = 0;
                    decimal avg = 0;

                    for (int j = 1; j <= list.Length; j++) {
                        
                        if (max > list[j]){
                            max = max;
                        } 
                        
                        else if (min < list[j]){                        
                            min = min;
                        }
                    }
                    Console.WriteLine(max);
                    Console.WriteLine(min);
                    */

                }

            }


            /*for (int i = 1; i < 10; i++) {
                list.Add(userNumberEntry); 
            }
            */
        }
    }
}
    

